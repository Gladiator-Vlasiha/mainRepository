package org.codewithoutus.tgbotusers.bot.exception;

public class CallbackDataMappingException extends RuntimeException {

    public CallbackDataMappingException(String message) {
        super(message);
    }
}