package org.codewithoutus.tgbotusers.bot.enums;

public enum BotStatus {
    START,
    STOP
}