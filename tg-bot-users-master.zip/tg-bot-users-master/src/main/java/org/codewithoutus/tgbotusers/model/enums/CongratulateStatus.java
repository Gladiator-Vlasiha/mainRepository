package org.codewithoutus.tgbotusers.model.enums;

public enum CongratulateStatus {
    WAIT,
    CONGRATULATE,
    DECLINE
}
